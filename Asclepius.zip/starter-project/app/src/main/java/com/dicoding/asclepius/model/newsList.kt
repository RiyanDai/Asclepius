package com.dicoding.asclepius.model

data class newsList(
    var totalResults: Int,
    var articles: List<newsData>
)
