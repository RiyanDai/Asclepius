package com.dicoding.asclepius.model

class source constructor(var id: String, var name: String) {
}